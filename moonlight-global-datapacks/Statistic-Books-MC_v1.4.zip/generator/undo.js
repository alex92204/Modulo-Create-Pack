
const fs = require("fs");

run();
function run() {
    let vt = fs.readFileSync("./vt_load.mcfunction", "utf-8");
    let all = fs.readFileSync("../data/sb/functions/setup_objectives.mcfunction", "utf8");

    let splitKeep = vt.split("\n");
    let splitAll = all.split("\n");

    let splitKeepSet = new Set();

    splitKeep = splitKeep.map((el) => {
        let obj = getObjective(el);
        if(splitKeep.includes(obj)) console.log("duplicate", obj);
        if(obj) splitKeepSet.add(obj);
        return obj;
    });
    console.log(splitKeepSet.size);

    for (let i = 0; i < splitAll.length; i++) {
        let obj = getObjective(splitAll[i]);
        if (!obj) continue;
        if (!splitKeep.includes(obj)) continue;
        splitAll.splice(i, 1);
        i--;
    }

    fs.writeFileSync("./remove.mcfunction", splitAll.reduce((prev, current) => prev += "\n" + current.replace("add", "remove").replace(/[\W]*\S+[\W]*$/, '')));


}

/**
 * 
 * @param {string} input 
 */
function getObjective(input) {
    input = input.trim();
    if (input.length === 0) return;
    if (input[0] === "#") return;
    if (!input.startsWith("scoreboard objectives")) return;
    return input.split(" ")[4].replace("minecraft.", "").replace("minecraft.", "");
}