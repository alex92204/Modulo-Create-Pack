execute store result score @s tooltrims.amount run clear @s rabbit_spawn_egg[minecraft:custom_model_data=314001]
loot give @s loot tooltrims:migration_v2/give_toolsmithing_table_ingredients